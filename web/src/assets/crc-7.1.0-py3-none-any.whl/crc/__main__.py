"""Main entrypoint for the package, to ensure it's runnable, ie: `python -m crc`."""

from ._crc import main  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    main()  # pragma: no cover
